e2
e2 - null
e1
e1 - null
Erreur a la ligne 6, colone 22.
L'ident 'e1' existe deja
e1
e1 - null
v3
v3 - eclairage
v2
v2 - eclairage
v1
v1 - eclairage
Erreur a la ligne 7, colone 22.
L'ident 'v1' existe deja
v1
v1 - eclairage
hf
hf - volet
r1
r1 - volet
Erreur a la ligne 9, colone 20.
L'ident 'r1' existe deja
r1
r1 - volet
a2
a2 - chauffage
a1
a1 - chauffage
Erreur a la ligne 10, colone 17.
L'ident 'a1' existe deja
a1
a1 - chauffage
v5
v5 - alarme
fen
fen - volet
cafe
cafe - fenetre
matv
matv - fenetre
proj
proj - fenetre
lv
lv - fenetre
ll
ll - fenetre
port
port - fenetre
ordi1
ordi1 - fenetre
ordi
ordi - fenetre
Erreur a la ligne 19, colone 47.
L'ident 'ordi' existe deja
ordi
ordi - fenetre
mon_eclairage_salon - null
elec_salon - fenetre
bonjour,null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.OUVRIR);},null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ETEINDRE);,null
if (appareil.typeAppareil.equals(TypeAppareil.fenetre)) appareil.appliquer(TypeActionAppareil.ALLUMER);,nullif(rad1.ETAT==eteint){
null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ALLUMER);}
,null
if (appareil.typeAppareil.equals(TypeAppareil.volet)) appareil.appliquer(TypeActionAppareil.ALLUMER);
soiree,null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.FERMER);},null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ALLUMER);}
soiree_musique,nullexecuter_scenario,soiree,null
if (appareil.typeAppareil.equals(TypeAppareil.volet)) appareil.appliquer(TypeActionAppareil.ALLUMER);
depart,null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.FERMER);},null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ETEINDRE);},nullif(fen.ETAT==ferme){
null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ALLUMER);}else{
nullnull,"Attention : la fenetre ",fen
}
,null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ETEINDRE);}
test,null
for(CAppareil appareil : this.l_appareils){nullnull,"Etat de ",e},null
for(CAppareil appareil : this.l_appareils){null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ALLUMER);},nullexecuter_scenario,soiree_musique,nullif(a1.ETAT==eteint){
null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ALLUMER_PARTIEL);}
,nullif(a1.ETAT==demi){
null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ALLUMER);}else{
nullif(a1.ETAT==allume){
null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ETEINDRE);}else{
null
if (appareil.typeAppareil.equals(TypeAppareil.chauffage)) appareil.appliquer(TypeActionAppareil.ALLUMER);
}

}
,nullif(r1.ETAT==eco){
null
if (appareil.typeAppareil.equals(TypeAppareil.volet)) appareil.appliquer(TypeActionAppareil.ALLUMER);}
,nullif(r1.ETAT==eteint){
null
if (appareil.typeAppareil.equals(TypeAppareil.volet)) appareil.appliquer(TypeActionAppareil.ALLUMER_ECO);}else{
nullif(r1.ETAT==allume){
null
if (appareil.typeAppareil.equals(TypeAppareil.volet)) appareil.appliquer(TypeActionAppareil.ETEINDRE);}else{
nullnull," bip !",null
}

}
,nullif(fen.ETAT==ouvert){
nullnull,"fenetre ouverte !",null}
,nullif(cafe.ETAT==allume){
null
if (appareil.typeAppareil.equals(TypeAppareil.fenetre)) appareil.appliquer(TypeActionAppareil.ETEINDRE);}
,nullif(cafe.ETAT==eteint){
null
if (appareil.typeAppareil.equals(TypeAppareil.fenetre)) appareil.appliquer(TypeActionAppareil.ALLUMER);}

test2,nullif(e1.ETAT==eteint){
null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ALLUMER);}else{
nullif(e1.ETAT==demi){
null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.ETEINDRE);}

}
,nullif(e2.ETAT==allume){
null
if (appareil.typeAppareil.equals(TypeAppareil.null)) appareil.appliquer(TypeActionAppareil.TAMISER);}
,nullif(v1.ETAT==ouvert){
null
if (appareil.typeAppareil.equals(TypeAppareil.eclairage)) appareil.appliquer(TypeActionAppareil.FERMER_PARTIEL);}
,nullif(v1.ETAT==ferme){
null
if (appareil.typeAppareil.equals(TypeAppareil.eclairage)) appareil.appliquer(TypeActionAppareil.OUVRIR_PARTIEL);,nullnull," alors ",null}else{
nullif(v1.ETAT==demi){
null
if (appareil.typeAppareil.equals(TypeAppareil.eclairage)) appareil.appliquer(TypeActionAppareil.FERMER);}else{
null
if (appareil.typeAppareil.equals(TypeAppareil.eclairage)) appareil.appliquer(TypeActionAppareil.OUVRIR);,nullnull," sinon ",null
}

}

public class CMaisonUser extends CMaison {
  public CMaisonUser() {
  super();

// Les appareils

    CEclairage e1 = new CEclairage("e1",TypeAppareil.ECLAIRAGE);
    ma_liste_appareils.add(e1);
    CVolet v1 = new CVolet("v1",TypeAppareil.VOLET);
    ma_liste_appareils.add(v1);
    CAutre_appareil hf = new CAutre_appareil("hf",TypeAppareil.AUTRE_APPAREIL_HIFI);
    ma_liste_appareils.add(hf);
    CChauffage r1 = new CChauffage("r1",TypeAppareil.CHAUFFAGE);
    ma_liste_appareils.add(r1);
    CAlarme a1 = new CAlarme("a1",TypeAppareil.ALARME);
    ma_liste_appareils.add(a1);
    CVolet v5 = new CVolet("v5",TypeAppareil.VOLET);
    ma_liste_appareils.add(v5);
    CFenetre fen = new CFenetre("fen",TypeAppareil.FENETRE);
    ma_liste_appareils.add(fen);
    CAutre_appareil cafe = new CAutre_appareil("cafe",TypeAppareil.AUTRE_APPAREIL_CAFE);
    ma_liste_appareils.add(cafe);
    CAutre_appareil matv = new CAutre_appareil("matv",TypeAppareil.AUTRE_APPAREIL_TV);
    ma_liste_appareils.add(matv);
    CAutre_appareil proj = new CAutre_appareil("proj",TypeAppareil.AUTRE_APPAREIL_VP);
    ma_liste_appareils.add(proj);
    CAutre_appareil lv = new CAutre_appareil("lv",TypeAppareil.AUTRE_APPAREIL_LV);
    ma_liste_appareils.add(lv);
    CAutre_appareil ll = new CAutre_appareil("ll",TypeAppareil.AUTRE_APPAREIL_LL);
    ma_liste_appareils.add(ll);
    CAutre_appareil port = new CAutre_appareil("port",TypeAppareil.AUTRE_APPAREIL_PORTAIL);
    ma_liste_appareils.add(port);
    CAutre_appareil ordi = new CAutre_appareil("ordi",TypeAppareil.AUTRE_APPAREIL_ORDINATEUR);
    ma_liste_appareils.add(ordi);
    CEnsAppareil mon_eclairage_salon = new CEnsAppareil("mon_eclairage_salon");
    mon_eclairage_salon.addAppareil(e2)
    mon_eclairage_salon.addAppareil(e3)
    mon_eclairage_salon.add(mon_eclairage_salon);
    CEnsAppareil elec_salon = new CEnsAppareil("elec_salon");
    elec_salon.addAppareil(matv)
    elec_salon.addAppareil(proj)
    elec_salon.addAppareil(ordi)
    elec_salon.add(elec_salon);

// Les interfaces

    CInterface b1 = new CInterface("b1",TypeInterface.INTERRUPTEUR);
    ma_liste_interfaces.add(b1);
    CInterface t1 = new CInterface("t1",TypeInterface.MOBILE);
    ma_liste_interfaces.add(t1);
    CInterface tel1 = new CInterface("tel1",TypeInterface.TELEPHONE);
    ma_liste_interfaces.add(tel1);
    CInterface tab1 = new CInterface("tab1",TypeInterface.TABLETTE);
    ma_liste_interfaces.add(tab1);
    CInterface zap = new CInterface("zap",TypeInterface.TELECOMMANDE);
    ma_liste_interfaces.add(zap);
    CInterface b2 = new CInterface("b2",TypeInterface.INTERRUPTEUR);
    ma_liste_interfaces.add(b2);

// Les scenarii

    monHabitat = new HabitatSpecific(ma_liste_appareils,
      ma_liste_ens_appareils, ma_liste_scenarios,
      ma_liste_interfaces, ma_liste_programmations);
   }
}

