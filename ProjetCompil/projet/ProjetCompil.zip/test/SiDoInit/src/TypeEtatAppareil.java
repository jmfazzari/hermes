

// a subdiviser en fct de l'appareil !!

public enum TypeEtatAppareil {
		 ALLUME, ETEINT, DEMI,
		 ECO,
		 OUVERT, FERME
		}